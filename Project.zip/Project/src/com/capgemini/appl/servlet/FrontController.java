package com.capgemini.appl.servlet;

import java.io.IOException;
import java.sql.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.capgemini.appl.dto.Application;
import com.capgemini.appl.dto.ProgramsOffered;
import com.capgemini.appl.dto.ProgramsScheduled;
import com.capgemini.appl.exception.UniversityAdmissionException;
import com.capgemini.appl.service.UniversityService;
import com.capgemini.appl.service.UniversityServiceImpl;

@WebServlet("*.do")
public class FrontController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private RequestDispatcher requestDispatcher;
	private String nextJspString;
	String msg = null;
	private ServletContext ctxContext;
	UniversityService service = null;

	public FrontController() {
		super();
		try {
			service = new UniversityServiceImpl();
		} catch (UniversityAdmissionException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void init() throws ServletException {

	}

	private void processRequest(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		String command = request.getServletPath();
		switch (command) {
		case "/showApplicant.do": {
			try {
				HttpSession log=request.getSession(false);
				System.out.println("xyxyyx");
			String logRight=	(String) log.getAttribute("logRight");
				System.out.println((String) log.getAttribute("logRight"));
				if(logRight.equals("mac"))
				{	
					System.out.println("xyxyyx");try {
						System.out.println("xyxyyx");
					List<Application> list = service.showApplications();
					request.setAttribute("list", list);
					nextJspString = "/showApplicant.jsp";
				} catch (UniversityAdmissionException e) {
					// TODO Auto-generated catch block
					//e.printStackTrace();
				request.setAttribute("msg", e);
				nextJspString = "/error.jsp";
				}}
				else{
					nextJspString = "/login.jsp";
					
				}
			} catch (Exception e) {
				// TODO Auto-generated catch block
				nextJspString = "/login.jsp";
				e.printStackTrace();
			}
		}
			break;

		case "/interview.do": {
			

			
			int applicationid = Integer.parseInt(request
					.getParameter("applicant"));
			String full_name = request.getParameter("name");
			request.setAttribute("Application_id", applicationid);
			request.setAttribute("full_name", full_name);
			nextJspString = "/interviewDate.jsp";

		}
			break;
		case "/accept.do": {
			Boolean checkDateBoolean=false;
			
			int applicationid = Integer.parseInt(request.getParameter("id"));
			String d = request.getParameter("interview").toString();

			// ///////////////

			SimpleDateFormat sdf1 = new SimpleDateFormat("yyyy-MM-dd");
			java.util.Date date;
			
			try {
				date = sdf1.parse(d);
				java.sql.Date dateCompare = new java.sql.Date(Calendar.getInstance().getTime().getTime());
				
				java.sql.Date sqlStartDate = new Date(date.getTime());
				if(sqlStartDate.compareTo(dateCompare)>0)
				{		checkDateBoolean=true;
					
				
				}
				else if(sqlStartDate.toString().trim().equals(dateCompare.toString().trim())){
					checkDateBoolean=true;
				
				}
				else if(sqlStartDate.compareTo(dateCompare)<0) {
					checkDateBoolean=false;
				}
				if(checkDateBoolean){
					Application application = new Application(applicationid,
							"accepted", sqlStartDate);
					service.acceptOrRejectApplication(application);
					nextJspString = "/showApplicant.do";
				}
				
				else {
					
					request.setAttribute("msg", "please Enter Correct Date");
					nextJspString = "/error.jsp";
					
				}
			

			} catch (ParseException | UniversityAdmissionException e) {

				request.setAttribute("msg", e);
				nextJspString = "/error.jsp";
			}

		

		}
			break;
		case "/reject.do": {

			int applicationid = Integer.parseInt(request
					.getParameter("applicant"));
			Application application = new Application(applicationid, "rejected");

			try {
				service.acceptOrRejectApplication(application);
			} catch (UniversityAdmissionException e) {
				// TODO Auto-generated catch block
			//	e.printStackTrace();
				request.setAttribute("msg", e);
				nextJspString = "/error.jsp";
			}		
			nextJspString = "/showApplicant.do";

		}
			break;

		case "/addProgram.do": {
			String ProgramName = request.getParameter("ProgramName");
			String description = request.getParameter("description");
			String applicantEligility = request
					.getParameter("eligibility");
			int duration = Integer.parseInt(request.getParameter("duration"));
			String degree_certificate_offered = request
					.getParameter("degree_certificate_offered");
			ProgramsOffered programsOffered = new ProgramsOffered(ProgramName,
					description, applicantEligility, duration,
					degree_certificate_offered);
			try {
				boolean success = service.addProgram(programsOffered);
				if (success) {
					nextJspString = "/showAllProgram.do";

				} else {

				}
			} catch (UniversityAdmissionException e) {
				// TODO Auto-generated catch block
			//	e.printStackTrace();
				request.setAttribute("msg", e);
				nextJspString = "/error.jsp";
			}

		}
			break;
		case "/showAllProgram.do": {
			try {
				List<ProgramsOffered> list = service.showProgramsOffereds();
				request.setAttribute("list", list);
				nextJspString = "/showAllProgram.jsp";

			} catch (UniversityAdmissionException e) {
				// TODO Auto-generated catch block
			//	e.printStackTrace();
				request.setAttribute("msg", e);
				nextJspString = "/error.jsp";
			}

		}
			break;
		case "/updateProgram.do": {
			HttpSession session = request.getSession(true);
			String ProgramName = request.getParameter("ProgramName");
			String description = request.getParameter("description");
			String applicantEligility = request
					.getParameter("applicantEligility");
			int duration = Integer.parseInt(request.getParameter("duration"));
			String degree_certificate_offered = request
					.getParameter("degree_certificate_offered");
			// ////////////////////////
			session.setAttribute("ProgramName", ProgramName);
			// ////////////////

			ProgramsOffered programsOffered = new ProgramsOffered(ProgramName,
					description, applicantEligility, duration,
					degree_certificate_offered);
			request.setAttribute("programsOffered", programsOffered);
			nextJspString = "/showProgram.jsp";

		}
			break;

		case "/updateOneProgram.do": {
			// String ProgramName = request.getParameter("ProgramName");
			HttpSession session = request.getSession(false);
			String ProgramName = (String) session.getAttribute("ProgramName");
			session.invalidate();
			String description = request.getParameter("description");
			String applicantEligility = request.getParameter("eligibility");
			int duration = Integer.parseInt(request.getParameter("duration"));
			String degree_certificate_offered = request
					.getParameter("degree_certificate_offered");

			ProgramsOffered programsOffered = new ProgramsOffered(ProgramName,
					description, applicantEligility, duration,
					degree_certificate_offered);
			try {
				boolean updateprogram = service.updateProgram(programsOffered);
				if (updateprogram) {
					nextJspString = "/showAllProgram.do";
				}
			} catch (UniversityAdmissionException e) {
				// TODO Auto-generated catch block
			//	e.printStackTrace();
				request.setAttribute("msg", e);
				nextJspString = "/error.jsp";
			}

		}
			break;
		case "/delteProgram.do": {
			String ProgramName = request.getParameter("ProgramName");
			try {
				boolean programdelete = service.deleteProgram(ProgramName);
				if (programdelete) {
					nextJspString = "/showAllProgram.do";

				}
			} catch (UniversityAdmissionException e) {
				// TODO Auto-generated catch block
				//e.printStackTrace();
				request.setAttribute("msg", e);
				nextJspString = "/error.jsp";
			}

		}
			break;
		case "/addSingleProgram.do": {
			nextJspString = "/addProgram.jsp";
		}
			break;
		//////////////////////////////////////////Nehali

		case "/login.do": {
			nextJspString = "login.jsp";
		}break;
		case "/authenticate.do": {
			System.out.println("Authenticate");
			String user = request.getParameter("user");
			String pwd = request.getParameter("pwd");
			System.out.println(user +" "+ pwd);
			try {
				String role = service.isUserAuthanticate(user, pwd);
				if (role.equals("mac")) {
					HttpSession log=request.getSession(true);
					log.setAttribute("logRight", role);
					System.out.println(role);
					nextJspString = "member.jsp";
				}

				else if(role.equals("admin")) {
					nextJspString = "admin.jsp";
					HttpSession log=request.getSession(true);
					log.setAttribute("logRight", role);
				}
			} catch (UniversityAdmissionException e) {
				msg = "Not Authorized person of administrator or members of admission committee";
				request.setAttribute("msg", msg);
				nextJspString = "/login.jsp";
				
			}
			
		}break;
		
		case "/takeInterview.do":{
			List<ProgramsScheduled> schedule;
			try {
				schedule = service.getAllProgramSheduled();
				request.setAttribute("data", schedule);
				nextJspString = "showSheduleDetail.jsp";
			} catch (UniversityAdmissionException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}break;
		case "/retriveApplication.do": {
			System.out.println("retrive");
			
			String id = request.getQueryString();
			String ScheduleId = id.substring(3);
			System.out.println(ScheduleId);
			List<Application> applicationList = null;
			try {
				applicationList = service.getApplicationOnSheduledId(ScheduleId);
										
				if(applicationList.isEmpty()){
					msg = "participants Not exists";
					request.setAttribute("msg", msg);
					nextJspString = "/error.jsp";
					
				}else{
				
				System.out.println("hi"+applicationList);
				request.setAttribute("data", applicationList);
				nextJspString = "showAllApplicantsDetail.jsp";
				}
				
			} catch (UniversityAdmissionException e) {
				e.printStackTrace();
			}
			
			
		}break;
		case "/confirmed.do": {
			String id = request.getQueryString();
			String applicationId = id.substring(3);
			int applId = Integer.parseInt(applicationId);
			String status="confirmed";
			System.out.println(applId);
			try {
				boolean update = service.updateApplicationDB(applId, status);
				if (update==true) {
					List<ProgramsScheduled> schedule = service.getAllProgramSheduled();
					request.setAttribute("data", schedule);
					nextJspString="showSheduleDetail.jsp";
					} else {
						msg="Unable to accept application.";
						request.setAttribute("msg",msg);
						nextJspString = "/error.jsp";
					}
			

			} catch (UniversityAdmissionException e) {

				e.printStackTrace();
			}

		}break;
		case "/rejectCandidate.do": {
			String id = request.getQueryString();
			String applicationId = id.substring(3);
			int applId = Integer.parseInt(applicationId);
			String status="rejected";
			System.out.println(applId);
			try {
				boolean update = service.updateApplicationDB(applId,status);
				if (update==true) {
					List<ProgramsScheduled> schedule = service.getAllProgramSheduled();
					request.setAttribute("data", schedule);
					nextJspString="showSheduleDetail.jsp";
				} else {
					msg="Unable to reject application.";
					request.setAttribute("msg",msg);
					nextJspString = "/error.jsp";
				}
				

			} catch (UniversityAdmissionException e) {

				e.printStackTrace();
			}

		}break;
		case "/home.do": {
			nextJspString = "login.jsp";
		}break;

			
		case "/logOut.do": {
			HttpSession log=request.getSession(false);
			log.invalidate();
			nextJspString = "login.jsp";
		}break;
			
			
			//////////////////////////////////////////
		case "/statusReport.do": {
			java.util.Date startDate1;
			java.util.Date endDate1;
			java.sql.Date sqlStartDate = null;
			java.sql.Date sqlEndDate = null;
			String status = request.getParameter("status");

			String startdate = request.getParameter("startdate");
			System.out.println("Userstartdate:" + startdate);

			String enddate = request.getParameter("enddate");
			System.out.println("UserEnddate" + enddate);

			try {
				SimpleDateFormat formatter1 = new SimpleDateFormat("yyyy-MM-dd");
				SimpleDateFormat formatter2 = new SimpleDateFormat("yyyy-MM-dd");

				startDate1 = formatter1.parse(startdate);
				System.out.println("startdateutil:" + startDate1);

				sqlStartDate = new Date(startDate1.getTime());
				System.out.println("sqlStartDate" + sqlStartDate);

				endDate1 = formatter2.parse(enddate);
				System.out.println("enddateutil:" + endDate1);

				sqlEndDate = new Date(endDate1.getTime());
				System.out.println("sqlEndDate" + sqlEndDate);

			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			List<Application> myList = null;
			try {

				myList = service.showApplicantInfo(status,sqlStartDate, sqlEndDate);
				System.out.println("In Controller" + myList);
				if (myList.isEmpty()) {

					String error = "Please enter valid input";
					System.out.println(error);
					request.setAttribute("errorMsg", error);
					RequestDispatcher reqs = request.getRequestDispatcher("candidateReport.jsp");
					reqs.forward(request, response);
					throw new UniversityAdmissionException("User has not entered valid input");

				} else {
					request.setAttribute("applicantinfo", myList);
					RequestDispatcher reqs = request
							.getRequestDispatcher("candidateInfo.jsp");
					reqs.forward(request, response);
				}

			} catch (UniversityAdmissionException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				
			}

			

		}
		break;
		//////////////////////////////////
		
		
		
		}

		requestDispatcher = request.getRequestDispatcher(nextJspString);
		requestDispatcher.forward(request, response);

	}

	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		processRequest(request, response);
	}

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		processRequest(request, response);
	}

	public void destroy() {
	}

}
