create table Location(
 LocationID varchar2(10) primary key,
 city varchar2(10),
 hstate varchar2(10),
 zip varchar2(10)
 );
 
  create table Programs_Scheduled (
 Scheduled_program_id varchar2(5) primary key,
 ProgramName varchar2(15),
 LocationID varchar2(10)  REFERENCES Location(LocationID) ,
 start_date date,
 end_date date,
 sessions_per_week number
 );
 
 Create Sequence scheduled_program_id start with 501 increment by 1;
 
 
 Insert into Location values(101,'Mumbai','Maha',400092);
Insert into Location values(102,'Pune','Maha',400123);
Insert into Location values(103,'Patna','MP',400628);
Insert into Location values(104,'Kanpur','UP',400593);
Insert into Location values(105,'Kolkata','WestB',400236);
Insert into Location values(106,'Nigdi','MP',400638);

Insert into Programs_Scheduled values(501,'Core Java',103,'13-JUN-2017','13-SEP-2017',6);
 Insert into Programs_Scheduled values(502,'.NET',101,'13-JUN-2017','13-SEP-2017',5);
 Insert into Programs_Scheduled values(503,'SocialAnalytics',104,'13-JUN-2017','13-SEP-2017',5);
  Insert into Programs_Scheduled values(504,'Database',104,'13-JUN-2017','13-SEP-2017',5);

  
  Drop table Location;
  
  Drop table Programs_Scheduled;
  
  SELECT Scheduled_program_id,ProgramName  FROM Programs_Scheduled where((ProgramName='.NET') AND (start_date>='13-JUN-2017') AND (end_date<='13-SEP-2017'));
  
  